<?php
include '../config/db.php';
include '../includes/header.php';

$id = $_GET['id'];
$sql = "SELECT p.*, m.nama_lapak FROM products p JOIN merchants m ON p.merchant_id = m.id WHERE p.id = $id";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
  $row = $result->fetch_assoc();
?>
<div class="row">
  <div class="col-md-6">
    <img src="<?= $row['foto_produk_url'] ?>" class="img-fluid" alt="Produk">
  </div>
  <div class="col-md-6">
    <h3><?= $row['nama_sayur'] ?></h3>
    <p><?= $row['deskripsi'] ?></p>
    <p><strong>Harga:</strong> Rp<?= number_format($row['harga'],0,',','.') ?> / <?= $row['satuan'] ?></p>
    <p><strong>Stok:</strong> <?= $row['stok_hari_ini'] ?></p>
    <p><strong>Lapak:</strong> <?= $row['nama_lapak'] ?></p>
    <form method="post" action="cart.php">
      <input type="hidden" name="product_id" value="<?= $row['id'] ?>">
      <div class="mb-2">
        <label>Jumlah:</label>
        <input type="number" name="quantity" value="1" min="1" max="<?= $row['stok_hari_ini'] ?>" class="form-control" required>
      </div>
      <button type="submit" class="btn btn-primary">Tambah ke Keranjang</button>
    </form>
  </div>
</div>
<?php
} else {
  echo "<p>Produk tidak ditemukan</p>";
}
include '../includes/footer.php';
?>