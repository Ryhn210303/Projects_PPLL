<?php
include '../config/db.php';
include '../includes/header.php';

$sql = "SELECT p.*, m.nama_lapak FROM products p JOIN merchants m ON p.merchant_id = m.id WHERE p.is_available = 1 ORDER BY p.created_at DESC";
$result = $conn->query($sql);
?>
<h3>Produk Sayuran Tersedia</h3>
<div class="row">
<?php while($row = $result->fetch_assoc()): ?>
  <div class="col-md-4 mb-4">
    <div class="card">
      <img src="<?= $row['foto_produk_url'] ?>" class="card-img-top" style="height: 200px; object-fit: cover;">
      <div class="card-body">
        <h5 class="card-title"><?= $row['nama_sayur'] ?></h5>
        <p class="card-text">Rp<?= number_format($row['harga'],0,',','.') ?> / <?= $row['satuan'] ?></p>
        <p class="card-text"><small class="text-muted">Lapak: <?= $row['nama_lapak'] ?></small></p>
        <a href="product_detail.php?id=<?= $row['id'] ?>" class="btn btn-sm btn-success">Lihat Detail</a>
      </div>
    </div>
  </div>
<?php endwhile; ?>
</div>
<?php include '../includes/footer.php'; ?>