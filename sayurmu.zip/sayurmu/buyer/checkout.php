<?php
include '../config/db.php';
session_start();
include '../includes/header.php';

if (!isset($_SESSION['user']) || $_SESSION['user']['role'] != 'pembeli') {
  echo "<script>window.location='../auth/login.php';</script>";
  exit;
}

$user_id = $_SESSION['user']['id'];
$cart = $_SESSION['cart'];
if (!$cart) {
  echo "<script>alert('Keranjang kosong'); window.location='marketplace.php';</script>";
  exit;
}

// Ambil merchant_id dari salah satu produk
$first_product = array_key_first($cart);
$merchant = $conn->query("SELECT merchant_id FROM products WHERE id = $first_product")->fetch_assoc();
$merchant_id = $merchant['merchant_id'];

$total = 0;
foreach ($cart as $pid => $qty) {
  $harga = $conn->query("SELECT harga FROM products WHERE id = $pid")->fetch_assoc()['harga'];
  $total += $harga * $qty;
}

$conn->query("INSERT INTO orders (user_id, merchant_id, total_harga) VALUES ($user_id, $merchant_id, $total)");
$order_id = $conn->insert_id;

foreach ($cart as $pid => $qty) {
  $harga = $conn->query("SELECT harga FROM products WHERE id = $pid")->fetch_assoc()['harga'];
  $sub = $harga * $qty;
  $conn->query("INSERT INTO order_items (order_id, product_id, quantity, harga_satuan, subtotal) VALUES ($order_id, $pid, $qty, $harga, $sub)");
}

unset($_SESSION['cart']);
echo "<script>alert('Pesanan berhasil dibuat'); window.location='orders.php';</script>";
?>