<?php
include '../config/db.php';
session_start();
include '../includes/header.php';

if (!isset($_SESSION['user']) || $_SESSION['user']['role'] != 'pembeli') {
  echo "<script>window.location='../auth/login.php';</script>";
  exit;
}

if (!isset($_SESSION['cart'])) {
  $_SESSION['cart'] = [];
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $product_id = $_POST['product_id'];
  $qty = $_POST['quantity'];
  $_SESSION['cart'][$product_id] = $qty;
  echo "<script>alert('Ditambahkan ke keranjang'); window.location='marketplace.php';</script>";
}

echo "<h3>Keranjang Belanja</h3>";
if (empty($_SESSION['cart'])) {
  echo "<p>Keranjang kosong</p>";
} else {
  $ids = implode(',', array_keys($_SESSION['cart']));
  $query = $conn->query("SELECT * FROM products WHERE id IN ($ids)");
  echo "<form method='post' action='checkout.php'>";
  echo "<table class='table'><thead><tr><th>Produk</th><th>Harga</th><th>Jumlah</th><th>Subtotal</th></tr></thead><tbody>";
  $total = 0;
  while ($p = $query->fetch_assoc()) {
    $qty = $_SESSION['cart'][$p['id']];
    $sub = $qty * $p['harga'];
    $total += $sub;
    echo "<tr><td>{$p['nama_sayur']}</td><td>Rp" . number_format($p['harga'], 0, ',', '.') . "</td><td>{$qty}</td><td>Rp" . number_format($sub, 0, ',', '.') . "</td></tr>";
  }
  echo "</tbody></table>";
  echo "<p><strong>Total: Rp" . number_format($total, 0, ',', '.') . "</strong></p>";
  echo "<button type='submit' class='btn btn-success'>Checkout</button>";
  echo "</form>";
}
include '../includes/footer.php';
?>