<?php
include '../config/db.php';
session_start();
include '../includes/header.php';

if (!isset($_SESSION['user']) || $_SESSION['user']['role'] != 'pembeli') {
  echo "<script>window.location='../auth/login.php';</script>";
  exit;
}

$user_id = $_SESSION['user']['id'];
$sql = "SELECT o.*, m.nama_lapak FROM orders o JOIN merchants m ON o.merchant_id = m.id WHERE o.user_id = $user_id ORDER BY o.created_at DESC";
$result = $conn->query($sql);
?>
<h3>Riwayat Pesanan Anda</h3>
<table class="table">
  <thead><tr><th>Lapak</th><th>Tanggal</th><th>Total</th><th>Status</th></tr></thead>
  <tbody>
    <?php while($row = $result->fetch_assoc()): ?>
      <tr>
        <td><?= $row['nama_lapak'] ?></td>
        <td><?= $row['tanggal_pesanan'] ?></td>
        <td>Rp<?= number_format($row['total_harga'], 0, ',', '.') ?></td>
        <td><?= ucfirst(str_replace('_', ' ', $row['status_pesanan'])) ?></td>
      </tr>
    <?php endwhile; ?>
  </tbody>
</table>
<?php include '../includes/footer.php'; ?>