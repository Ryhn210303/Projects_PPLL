<?php
include '../config/db.php';
session_start();
include '../includes/header.php';

if (!isset($_SESSION['user'])) {
  echo "<script>window.location='../auth/login.php';</script>";
  exit;
}

$me = $_SESSION['user']['id'];
$partner = $_GET['to'] ?? null;

if ($partner) {
  $nama = $conn->query("SELECT nama_lengkap FROM users WHERE id = $partner")->fetch_assoc()['nama_lengkap'];
  echo "<h4>Chat dengan $nama</h4>";

  $res = $conn->query("SELECT * FROM messages WHERE (sender_id = $me AND receiver_id = $partner) OR (sender_id = $partner AND receiver_id = $me) ORDER BY sent_at ASC");
  echo "<div style='border:1px solid #ccc; padding:10px; height:300px; overflow-y:scroll'>";
  while ($msg = $res->fetch_assoc()) {
    $class = $msg['sender_id'] == $me ? 'text-end text-primary' : 'text-start text-success';
    echo "<p class='$class'><strong>" . ($msg['sender_id'] == $me ? 'Anda' : $nama) . ":</strong> {$msg['message']}<br><small>{$msg['sent_at']}</small></p>";
  }
  echo "</div>";
  ?>

  <form action="send_message.php" method="post" class="mt-2">
    <input type="hidden" name="to" value="<?= $partner ?>">
    <textarea name="message" class="form-control mb-2" placeholder="Tulis pesan..." required></textarea>
    <button type="submit" class="btn btn-primary">Kirim</button>
  </form>

  <?php
} else {
  echo "<p>Pilih pengguna untuk memulai chat.</p>";
  $users = $conn->query("SELECT id, nama_lengkap, role FROM users WHERE id != $me");
  while ($u = $users->fetch_assoc()) {
    echo "<p><a href='chatbox.php?to={$u['id']}'>Chat dengan {$u['nama_lengkap']} ({$u['role']})</a></p>";
  }
}
include '../includes/footer.php';
?>