<?php
include '../config/db.php';
session_start();

if (!isset($_SESSION['user'])) exit;

$sender = $_SESSION['user']['id'];
$receiver = $_POST['to'];
$message = $conn->real_escape_string($_POST['message']);

$conn->query("INSERT INTO messages (sender_id, receiver_id, message) VALUES ($sender, $receiver, '$message')");
header("Location: chatbox.php?to=$receiver");