<?php
include '../config/db.php';
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nama = $_POST['nama'];
    $email = $_POST['email'];
    $telepon = $_POST['telepon'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $role = $_POST['role'];
    $alamat = $_POST['alamat'];

    $stmt = $conn->prepare("INSERT INTO users (nama_lengkap, email, no_telepon, password, role, alamat) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("ssssss", $nama, $email, $telepon, $password, $role, $alamat);
    if ($stmt->execute()) {
        echo "<script>alert('Registrasi berhasil'); window.location='login.php';</script>";
    } else {
        echo "<script>alert('Gagal registrasi');</script>";
    }
}
?>

<?php include '../includes/header.php'; ?>
<h3>Registrasi</h3>
<form method="post">
  <input type="text" name="nama" class="form-control mb-2" placeholder="Nama Lengkap" required>
  <input type="email" name="email" class="form-control mb-2" placeholder="Email">
  <input type="text" name="telepon" class="form-control mb-2" placeholder="No Telepon" required>
  <input type="password" name="password" class="form-control mb-2" placeholder="Password" required>
  <select name="role" class="form-control mb-2" required>
    <option value="pembeli">Pembeli</option>
    <option value="pedagang">Pedagang</option>
  </select>
  <textarea name="alamat" class="form-control mb-2" placeholder="Alamat"></textarea>
  <button type="submit" class="btn btn-primary">Daftar</button>
</form>
<?php include '../includes/footer.php'; ?>
