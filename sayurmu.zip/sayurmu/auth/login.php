<?php
include '../config/db.php';
session_start();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = $_POST['email'];
    $password = $_POST['password'];

    $sql = "SELECT * FROM users WHERE email = '$email'";
    $result = $conn->query($sql);
    $user = $result->fetch_assoc();

    if ($user && password_verify($password, $user['password'])) {
        $_SESSION['user'] = $user;
        if ($user['role'] == 'pedagang') {
            header('Location: ../merchant/dashboard.php');
        } else {
            header('Location: ../buyer/marketplace.php');
        }
    } else {
        echo "<script>alert('Login gagal');</script>";
    }
}
?>

<?php include '../includes/header.php'; ?>
<h3>Login</h3>
<form method="post">
  <input type="email" name="email" class="form-control mb-2" placeholder="Email" required>
  <input type="password" name="password" class="form-control mb-2" placeholder="Password" required>
  <button type="submit" class="btn btn-primary">Login</button>
</form>
<p>Belum punya akun? <a href="register.php">Daftar di sini</a></p>
<?php include '../includes/footer.php'; ?>
