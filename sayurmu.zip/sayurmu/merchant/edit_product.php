<?php
include '../config/db.php';
session_start();
include '../includes/header.php';

if (!isset($_SESSION['user']) || $_SESSION['user']['role'] != 'pedagang') {
  echo "<script>window.location='../auth/login.php';</script>";
  exit;
}

$id = $_GET['id'];
$produk = $conn->query("SELECT * FROM products WHERE id = $id")->fetch_assoc();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $nama = $_POST['nama'];
  $deskripsi = $_POST['deskripsi'];
  $harga = $_POST['harga'];
  $satuan = $_POST['satuan'];
  $stok = $_POST['stok'];

  // cek apakah user upload gambar baru
  if (!empty($_FILES['foto']['name'])) {
    $upload_dir = "../uploads/";
    $filename = basename($_FILES['foto']['name']);
    $target_file = $upload_dir . $filename;
    if (move_uploaded_file($_FILES['foto']['tmp_name'], $target_file)) {
      $foto = "/sayurmu/uploads/" . $filename;
    } else {
      echo "<script>alert('Upload gambar gagal');</script>";
      $foto = $produk['foto_produk_url'];
    }
  } else {
    $foto = $produk['foto_produk_url'];
  }

  $stmt = $conn->prepare("UPDATE products SET nama_sayur=?, deskripsi=?, harga=?, satuan=?, stok_hari_ini=?, foto_produk_url=? WHERE id=?");
  $stmt->bind_param("ssdsssi", $nama, $deskripsi, $harga, $satuan, $stok, $foto, $id);

  if ($stmt->execute()) {
    echo "<script>alert('Produk diperbarui'); window.location='dashboard.php';</script>";
  } else {
    echo "<script>alert('Gagal update');</script>";
  }
}
?>
<h3>Edit Produk</h3>
<form method="post" enctype="multipart/form-data">
  <input type="text" name="nama" value="<?= $produk['nama_sayur'] ?>" class="form-control mb-2" required>
  <textarea name="deskripsi" class="form-control mb-2"><?= $produk['deskripsi'] ?></textarea>
  <input type="file" name="foto" class="form-control mb-2">
  <label for="foto">Upload Foto Produk (opsional jika tidak ingin mengubah gambar)</label>
  <input type="file" name="foto" id="foto" class="form-control mb-2">
  <input type="number" step="0.01" name="harga" value="<?= $produk['harga'] ?>" class="form-control mb-2" required>
  <input type="text" name="satuan" value="<?= $produk['satuan'] ?>" class="form-control mb-2" required>
  <input type="number" name="stok" value="<?= $produk['stok_hari_ini'] ?>" class="form-control mb-2" required>
  <button type="submit" class="btn btn-primary">Update</button>
</form>
<?php include '../includes/footer.php'; ?>
