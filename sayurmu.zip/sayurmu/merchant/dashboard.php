<?php
include '../config/db.php';
session_start();
include '../includes/header.php';

if (!isset($_SESSION['user']) || $_SESSION['user']['role'] != 'pedagang') {
  echo "<script>window.location='../auth/login.php';</script>";
  exit;
}

$user_id = $_SESSION['user']['id'];
$sql = "SELECT * FROM merchants WHERE user_id = $user_id";
$lapak = $conn->query($sql)->fetch_assoc();

echo "<h3>Dashboard Pedagang</h3>";
if ($lapak): ?>
  <p>Selamat datang, <?= $_SESSION['user']['nama_lengkap'] ?>!</p>
  <p><strong>Nama Lapak:</strong> <?= $lapak['nama_lapak'] ?></p>
  <a href="add_product.php" class="btn btn-success">Tambah Produk</a>
  <a href="orders.php" class="btn btn-info">Lihat Pesanan</a>
<?php else: ?>
  <p>Anda belum memiliki lapak. Silakan buat di halaman <a href="profile.php">profil</a>.</p>
<?php endif; ?>
<?php include '../includes/footer.php'; ?>