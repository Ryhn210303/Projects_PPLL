
<?php
include '../config/db.php';
session_start();
include '../includes/header.php';

if (!isset($_SESSION['user']) || $_SESSION['user']['role'] != 'pedagang') {
  echo "<script>window.location='../auth/login.php';</script>";
  exit;
}

$user_id = $_SESSION['user']['id'];
$cek = $conn->query("SELECT * FROM merchants WHERE user_id = $user_id");
$lapak = $cek->fetch_assoc();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $nama_lapak = $_POST['nama_lapak'];
  $deskripsi = $_POST['deskripsi'];
  $area = $_POST['area'];
  $jadwal = $_POST['jadwal'];
  $foto = $_POST['foto'];
  $status = $_POST['status'];

  if ($lapak) {
    $stmt = $conn->prepare("UPDATE merchants SET nama_lapak=?, deskripsi=?, area_operasional=?, jadwal_rutin=?, foto_profil_url=?, status_pedagang=? WHERE user_id=?");
    $stmt->bind_param("ssssssi", $nama_lapak, $deskripsi, $area, $jadwal, $foto, $status, $user_id);
  } else {
    $stmt = $conn->prepare("INSERT INTO merchants (user_id, nama_lapak, deskripsi, area_operasional, jadwal_rutin, foto_profil_url, status_pedagang) VALUES (?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("issssss", $user_id, $nama_lapak, $deskripsi, $area, $jadwal, $foto, $status);
  }

  if ($stmt->execute()) {
    echo "<script>alert('Profil lapak disimpan'); window.location='dashboard.php';</script>";
  } else {
    echo "<script>alert('Gagal simpan profil');</script>";
  }
}
?>
<h3>Profil Lapak</h3>
<form method="post">
  <input type="text" name="nama_lapak" class="form-control mb-2" placeholder="Nama Lapak" value="<?= $lapak['nama_lapak'] ?? '' ?>" required>
  <textarea name="deskripsi" class="form-control mb-2" placeholder="Deskripsi Lapak"><?= $lapak['deskripsi'] ?? '' ?></textarea>
  <input type="text" name="area" class="form-control mb-2" placeholder="Area Operasional" value="<?= $lapak['area_operasional'] ?? '' ?>">
  <input type="text" name="jadwal" class="form-control mb-2" placeholder="Jadwal Rutin" value="<?= $lapak['jadwal_rutin'] ?? '' ?>">
  <input type="text" name="foto" class="form-control mb-2" placeholder="URL Foto Profil" value="<?= $lapak['foto_profil_url'] ?? '' ?>">
  <select name="status" class="form-control mb-2">
    <option value="online" <?= isset($lapak['status_pedagang']) && $lapak['status_pedagang']=='online'?'selected':'' ?>>Online</option>
    <option value="offline" <?= isset($lapak['status_pedagang']) && $lapak['status_pedagang']=='offline'?'selected':'' ?>>Offline</option>
  </select>
  <button type="submit" class="btn btn-primary">Simpan</button>
</form>
<?php include '../includes/footer.php'; ?>