<?php
include '../config/db.php';
session_start();
include '../includes/header.php';

if (!isset($_SESSION['user']) || $_SESSION['user']['role'] != 'pedagang') {
  echo "<script>window.location='../auth/login.php';</script>";
  exit;
}

$user_id = $_SESSION['user']['id'];
$merchant = $conn->query("SELECT id FROM merchants WHERE user_id = $user_id")->fetch_assoc();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $nama = $_POST['nama'];
  $deskripsi = $_POST['deskripsi'];
  $harga = $_POST['harga'];
  $satuan = $_POST['satuan'];
  $stok = $_POST['stok'];

  // ✅ Upload gambar
  $upload_dir = "../uploads/";
  $filename = basename($_FILES['foto']['name']);
  $target_file = $upload_dir . $filename;

  if (move_uploaded_file($_FILES['foto']['tmp_name'], $target_file)) {
    $foto = "/sayurmu/uploads/" . $filename;

    $stmt = $conn->prepare("INSERT INTO products (merchant_id, nama_sayur, deskripsi, harga, satuan, stok_hari_ini, foto_produk_url) VALUES (?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("issdsis", $merchant['id'], $nama, $deskripsi, $harga, $satuan, $stok, $foto);

    if ($stmt->execute()) {
      echo "<script>alert('Produk berhasil ditambahkan'); window.location='dashboard.php';</script>";
    } else {
      echo "<script>alert('Gagal menambahkan produk ke database');</script>";
    }
  } else {
    echo "<script>alert('Upload gambar gagal');</script>";
  }
}
?>

<h3>Tambah Produk Baru</h3>
<form method="post" enctype="multipart/form-data">
  <input type="text" name="nama" class="form-control mb-2" placeholder="Nama Sayur" required>
  <textarea name="deskripsi" class="form-control mb-2" placeholder="Deskripsi"></textarea>
  <label for="foto">Upload Foto Produk</label>
  <input type="file" name="foto" id="foto" class="form-control mb-2" required>
  <input type="number" step="0.01" name="harga" class="form-control mb-2" placeholder="Harga" required>
  <input type="text" name="satuan" class="form-control mb-2" placeholder="Satuan (misal: kg, ikat)" required>
  <input type="number" name="stok" class="form-control mb-2" placeholder="Stok Hari Ini" required>
  <button type="submit" class="btn btn-primary">Simpan</button>
</form>

<?php include '../includes/footer.php'; ?>