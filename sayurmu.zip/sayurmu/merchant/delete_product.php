<?php
include '../config/db.php';
session_start();

if (!isset($_SESSION['user']) || $_SESSION['user']['role'] != 'pedagang') {
  echo "<script>window.location='../auth/login.php';</script>";
  exit;
}

$id = $_GET['id'];
$conn->query("DELETE FROM products WHERE id = $id");
header('Location: dashboard.php');