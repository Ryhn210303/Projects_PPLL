<?php
include '../config/db.php';
session_start();
include '../includes/header.php';

if (!isset($_SESSION['user']) || $_SESSION['user']['role'] != 'pedagang') {
  echo "<script>window.location='../auth/login.php';</script>";
  exit;
}

$user_id = $_SESSION['user']['id'];
$merchant = $conn->query("SELECT id FROM merchants WHERE user_id = $user_id")->fetch_assoc();

$sql = "SELECT o.*, u.nama_lengkap FROM orders o JOIN users u ON o.user_id = u.id WHERE o.merchant_id = {$merchant['id']} ORDER BY o.created_at DESC";
$orders = $conn->query($sql);
?>
<h3>Pesanan Masuk</h3>
<table class="table">
  <thead><tr><th>Pembeli</th><th>Tanggal</th><th>Total</th><th>Status</th><th>Aksi</th></tr></thead>
  <tbody>
    <?php while($o = $orders->fetch_assoc()): ?>
      <tr>
        <td><?= $o['nama_lengkap'] ?></td>
        <td><?= $o['tanggal_pesanan'] ?></td>
        <td>Rp<?= number_format($o['total_harga'], 0, ',', '.') ?></td>
        <td><?= ucfirst(str_replace('_',' ', $o['status_pesanan'])) ?></td>
        <td>
          <form method="post">
            <input type="hidden" name="order_id" value="<?= $o['id'] ?>">
            <select name="status" class="form-select form-select-sm w-auto d-inline-block">
              <?php foreach (['pending','confirmed','prepared','on_delivery','completed','cancelled'] as $status): ?>
                <option value="<?= $status ?>" <?= $o['status_pesanan'] === $status ? 'selected' : '' ?>><?= ucfirst($status) ?></option>
              <?php endforeach; ?>
            </select>
            <button type="submit" class="btn btn-sm btn-primary">Ubah</button>
          </form>
        </td>
      </tr>
    <?php endwhile; ?>
  </tbody>
</table>

<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $id = $_POST['order_id'];
  $status = $_POST['status'];
  $conn->query("UPDATE orders SET status_pesanan='$status' WHERE id = $id");
  echo "<script>window.location='orders.php';</script>";
}
include '../includes/footer.php'; ?>
