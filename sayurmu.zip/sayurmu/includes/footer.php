</div>
<footer class="bg-light text-center p-3 mt-5">
  <p>&copy; 2025 Sayurmu Marketplace</p>
</footer>
</body>
</html>