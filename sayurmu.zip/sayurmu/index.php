<?php include 'includes/header.php'; ?>

<main>
  <header>
    <h1>Selamat Datang di Sayurmu</h1>
    <p>Marketplace sayuran segar langsung dari pedagang ke rumah Anda.</p>
  </header>
</main>

<?php include 'includes/footer.php'; ?>
